[![Build Status](https://travis-ci.org/yowcow/p5-MySample-Module.svg?branch=master)](https://travis-ci.org/yowcow/p5-MySample-Module)

MySample::Module
================

Building a module with Module::Build
